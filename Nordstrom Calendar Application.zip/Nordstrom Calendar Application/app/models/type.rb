class Type < ApplicationRecord
end
