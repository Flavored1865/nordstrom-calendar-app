class Department < ApplicationRecord
end
